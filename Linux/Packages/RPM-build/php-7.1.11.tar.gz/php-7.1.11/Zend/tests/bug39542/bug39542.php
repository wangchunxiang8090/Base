<?php
class bug39542 {
	function __construct() {
		echo "ok\n";
	}
}
?>
